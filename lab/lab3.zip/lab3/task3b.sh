#!/bin/bash
#./task3b.sh [filename1 filename2 ...... ]
for n in $@
do
mv ${n} ${n^^}
done
exit