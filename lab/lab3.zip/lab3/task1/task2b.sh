#!/bin/bash
echo "Hello"
exit
#using time command for compare running tinme