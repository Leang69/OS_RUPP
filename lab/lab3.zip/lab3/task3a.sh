#!/bin/bash
#./task3b.sh [filename1 filename2 ...... ]
for n in $@
do 
file $n
done
exit