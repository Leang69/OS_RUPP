#!/bin/bash
#./task4a.sh [filename] [startline] [endline]
fname=$1
start=$2
end=$3
sed -n $start,$end\p $fname
exit