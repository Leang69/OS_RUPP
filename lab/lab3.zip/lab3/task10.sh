#!/bin/bash
#./task10.sh [username]
ps -fu "$1"
