#!/bin/bash
echo $USER
exit