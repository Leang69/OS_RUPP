#!/bin/bash
#./task3c.sh [Username]
userloginTime=$(last --time iso|grep -w "$USER"|grep -w "still logged in"|awk '/tty/ {print $4}')
UnixTimestart=$(date -d "$userloginTime" +%"s")
UnixTimeNow=$(date +%"s")
Period=$(expr $UnixTimeNow - $UnixTimestart)
day=$(expr $Period % 31556926 % 2629743 / 86400)
hour=$(expr $Period % 31556926 % 2629743 % 86400 / 3600)
minu=$(expr $Period % 31556926 % 2629743 % 86400 % 3600 / 60)
sec=$(expr $Period % 31556926 % 2629743 % 86400 % 3600 % 60)
echo "User use this computer : " $day "Day" $hour "Hous" $minu "Minute" $sec "Second"
exit